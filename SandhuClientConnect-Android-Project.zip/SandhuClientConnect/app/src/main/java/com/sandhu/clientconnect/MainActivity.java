package com.sandhu.clientconnect;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentProviderOperation;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int CONTACT_PERMISSION = 41;
    private static final int BLUE = Color.rgb(12, 55, 125);
    private static final int ACCENT = Color.rgb(25, 111, 232);
    private static final int GREEN = Color.rgb(22, 163, 74);
    private EditText nameInput, phoneInput, searchInput;
    private LinearLayout listBox, root;
    private DB db;
    private boolean punjabi = false;
    private String pendingName, pendingPhone;
    private int editingId = -1;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new DB(this);
        buildScreen();
        renderCustomers("");
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private Button button(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setTextSize(14); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setBackground(bg(color, 14));
        b.setPadding(dp(8), dp(5), dp(8), dp(5)); return b;
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16), dp(12), dp(16), dp(24));
        root.setBackgroundColor(Color.rgb(244,247,252)); scroll.addView(root); setContentView(scroll);

        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(16),dp(14),dp(16),dp(14));
        header.setBackground(bg(BLUE,20)); header.setOrientation(LinearLayout.HORIZONTAL);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.app_logo); logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(logo,new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL); brand.setPadding(dp(12),0,0,0);
        brand.addView(text("SANDHU",24,Color.WHITE,true)); brand.addView(text("CLIENT CONNECT",13,Color.rgb(255,205,55),true));
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        Button lang=button("ਪੰ / EN",ACCENT); lang.setOnClickListener(v->{punjabi=!punjabi; buildScreen(); renderCustomers(searchInput==null?"":searchInput.getText().toString());});
        header.addView(lang); root.addView(header);

        TextView heading=text(punjabi?"ਨਵਾਂ ਗਾਹਕ ਜੋੜੋ":"Add New Customer",20,BLUE,true); heading.setPadding(dp(2),dp(20),0,dp(10)); root.addView(heading);
        LinearLayout form=new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(14),dp(12),dp(14),dp(14)); form.setBackground(bg(Color.WHITE,18));
        nameInput=new EditText(this); nameInput.setSingleLine(true); nameInput.setTextSize(16); nameInput.setHint(punjabi?"ਗਾਹਕ ਦਾ ਨਾਮ":"Customer name"); nameInput.setPadding(dp(12),dp(12),dp(12),dp(12)); nameInput.setBackground(bg(Color.rgb(246,248,252),12)); form.addView(nameInput,new LinearLayout.LayoutParams(-1,dp(52)));
        phoneInput=new EditText(this); phoneInput.setSingleLine(true); phoneInput.setTextSize(16); phoneInput.setInputType(3); phoneInput.setHint(punjabi?"ਮੋਬਾਈਲ ਨੰਬਰ":"Mobile number"); phoneInput.setPadding(dp(12),dp(12),dp(12),dp(12)); phoneInput.setBackground(bg(Color.rgb(246,248,252),12));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(52)); pp.topMargin=dp(10); form.addView(phoneInput,pp);
        Button save=button(punjabi?"ਸੇਵ ਕਰੋ + ਫੋਨਬੁੱਕ":"Save Customer + Phonebook",GREEN); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(50)); sp.topMargin=dp(12); form.addView(save,sp);
        save.setOnClickListener(v->saveCustomer()); root.addView(form);

        TextView sub=text(punjabi?"ਸੇਵ ਕੀਤੇ ਗਾਹਕ":"Saved Customers",20,BLUE,true); sub.setPadding(dp(2),dp(20),0,dp(8)); root.addView(sub);
        searchInput=new EditText(this); searchInput.setSingleLine(true); searchInput.setTextSize(15); searchInput.setHint(punjabi?"ਨਾਮ ਜਾਂ ਨੰਬਰ ਖੋਜੋ":"Search name or number"); searchInput.setPadding(dp(12),dp(8),dp(12),dp(8)); searchInput.setBackground(bg(Color.WHITE,14)); root.addView(searchInput,new LinearLayout.LayoutParams(-1,dp(48)));
        searchInput.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderCustomers(s.toString());} public void afterTextChanged(android.text.Editable e){}});
        listBox=new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(10); root.addView(listBox,lp);
        TextView note=text(punjabi?"ਨੋਟ: WhatsApp ਵਿੱਚ Hi ਪਹਿਲਾਂ ਭਰਿਆ ਹੋਵੇਗਾ। ਭੇਜਣ ਲਈ Send ਦਬਾਓ।":"Note: WhatsApp opens with Hi pre-filled. Tap Send yourself.",12,Color.GRAY,false); note.setPadding(dp(4),dp(14),dp(4),0); root.addView(note);
    }

    private void saveCustomer() {
        String name=nameInput.getText().toString().trim(); String phone=phoneInput.getText().toString().trim().replaceAll("[\\s()-]","");
        if(name.isEmpty()){nameInput.setError(punjabi?"ਨਾਮ ਲਿਖੋ":"Enter customer name");return;}
        if(phone.length()<7){phoneInput.setError(punjabi?"ਸਹੀ ਨੰਬਰ ਲਿਖੋ":"Enter a valid phone number");return;}
        pendingName=name; pendingPhone=phone;
        if(checkSelfPermission(Manifest.permission.WRITE_CONTACTS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.WRITE_CONTACTS},CONTACT_PERMISSION);return;}
        completeSave();
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==CONTACT_PERMISSION){if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED)completeSave();else { saveOnlyInApp(); Toast.makeText(this,"Saved in app only. Allow Contacts permission to also save to phonebook.",Toast.LENGTH_LONG).show(); }}}
    private void saveOnlyInApp(){
        if(pendingName==null)return;
        if(editingId>=0){db.update(editingId,pendingName,pendingPhone);editingId=-1;}else db.insert(pendingName,pendingPhone);
        nameInput.setText("");phoneInput.setText("");pendingName=null;pendingPhone=null;renderCustomers("");
    }
    private void completeSave(){
        if(pendingName==null)return;
        if(editingId>=0){db.update(editingId,pendingName,pendingPhone); editingId=-1;}
        else db.insert(pendingName,pendingPhone);
        boolean contactSaved=saveToPhonebook(pendingName,pendingPhone);
        nameInput.setText(""); phoneInput.setText(""); pendingName=null; pendingPhone=null;
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(phoneInput.getWindowToken(),0);
        renderCustomers("");
        Toast.makeText(this,contactSaved?"Saved in app and phonebook":"Saved in app; phonebook save failed",Toast.LENGTH_LONG).show();
    }
    private boolean saveToPhonebook(String name,String phone){
        try{
            ArrayList<ContentProviderOperation> ops=new ArrayList<>();
            ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI).withValue(ContactsContract.RawContacts.ACCOUNT_TYPE,null).withValue(ContactsContract.RawContacts.ACCOUNT_NAME,null).build());
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID,0).withValue(ContactsContract.Data.MIMETYPE,ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE).withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,name).build());
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID,0).withValue(ContactsContract.Data.MIMETYPE,ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE).withValue(ContactsContract.CommonDataKinds.Phone.NUMBER,phone).withValue(ContactsContract.CommonDataKinds.Phone.TYPE,ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE).build());
            getContentResolver().applyBatch(ContactsContract.AUTHORITY,ops); return true;
        }catch(Exception e){return false;}
    }
    private void renderCustomers(String query){
        if(listBox==null)return; listBox.removeAllViews(); Cursor c=db.search(query);
        if(c.getCount()==0){TextView empty=text(punjabi?"ਹਾਲੇ ਕੋਈ ਗਾਹਕ ਨਹੀਂ":"No customers saved yet",14,Color.GRAY,false); empty.setPadding(dp(12),dp(18),dp(12),dp(18)); listBox.addView(empty); c.close(); return;}
        while(c.moveToNext()){
            final int id=c.getInt(0); final String name=c.getString(1), phone=c.getString(2);
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(13),dp(12),dp(13),dp(12)); card.setBackground(bg(Color.WHITE,16)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.bottomMargin=dp(9); listBox.addView(card,cp);
            LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
            TextView initials=text(name.isEmpty()?"?":name.substring(0,1).toUpperCase(),18,Color.WHITE,true); initials.setGravity(Gravity.CENTER); initials.setBackground(bg(ACCENT,30)); top.addView(initials,new LinearLayout.LayoutParams(dp(42),dp(42)));
            LinearLayout details=new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL); details.setPadding(dp(10),0,0,0); details.addView(text(name,16,Color.rgb(25,35,55),true)); details.addView(text(phone,14,Color.DKGRAY,false)); top.addView(details,new LinearLayout.LayoutParams(0,-2,1));
            Button call=button("Call",ACCENT); top.addView(call,new LinearLayout.LayoutParams(dp(76),dp(42))); call.setOnClickListener(v->dial(phone)); card.addView(top);
            LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.END|Gravity.CENTER_VERTICAL); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(42)); ap.topMargin=dp(8);
            Button wa=button("WhatsApp",GREEN); actions.addView(wa); wa.setOnClickListener(v->whatsapp(phone));
            Button edit=button(punjabi?"ਸੋਧੋ":"Edit",Color.rgb(100,116,139)); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(dp(76),dp(42)); ep.leftMargin=dp(7); actions.addView(edit,ep); edit.setOnClickListener(v->editCustomer(id,name,phone));
            Button del=button(punjabi?"ਮਿਟਾਓ":"Delete",Color.rgb(220,53,69)); LinearLayout.LayoutParams dpv=new LinearLayout.LayoutParams(dp(82),dp(42)); dpv.leftMargin=dp(7); actions.addView(del,dpv); del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Delete this customer from app list? Phonebook contact will remain.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{db.delete(id);renderCustomers(searchInput.getText().toString());}).show());
            card.addView(actions,ap);
        }
        c.close();
    }
    private void editCustomer(int id,String name,String phone){editingId=id;nameInput.setText(name);phoneInput.setText(phone);nameInput.requestFocus();Toast.makeText(this,"Edit details above, then tap Save Customer",Toast.LENGTH_LONG).show();}
    private String international(String phone){String n=phone.replaceAll("[^0-9]","");if(n.length()==10)n="91"+n;return n;}
    private void whatsapp(String phone){String n=international(phone);try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+n+"?text=Hi"));startActivity(i);}catch(Exception e){Toast.makeText(this,"WhatsApp is not available",Toast.LENGTH_LONG).show();}}
    private void dial(String phone){try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+phone)));}catch(Exception e){Toast.makeText(this,"Unable to open dialer",Toast.LENGTH_LONG).show();}}

    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"sandhu_clients.db",null,1);} public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE clients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT NOT NULL,created_at INTEGER NOT NULL)");}
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        void insert(String n,String p){ContentValues v=new ContentValues();v.put("name",n);v.put("phone",p);v.put("created_at",System.currentTimeMillis());getWritableDatabase().insert("clients",null,v);}
        void update(int id,String n,String p){ContentValues v=new ContentValues();v.put("name",n);v.put("phone",p);getWritableDatabase().update("clients",v,"id=?",new String[]{String.valueOf(id)});}
        void delete(int id){getWritableDatabase().delete("clients","id=?",new String[]{String.valueOf(id)});}
        Cursor search(String q){return getReadableDatabase().rawQuery("SELECT id,name,phone FROM clients WHERE name LIKE ? OR phone LIKE ? ORDER BY id DESC",new String[]{"%"+q+"%","%"+q+"%"});}
    }
}
